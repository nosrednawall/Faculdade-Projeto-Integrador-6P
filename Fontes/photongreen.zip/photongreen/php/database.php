<?php
	$mysqli=new mysqli('localhost','photongreen','123456','photongreen');
?>
