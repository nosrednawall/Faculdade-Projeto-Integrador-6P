<?php 
    function sun(){
        return 1+1;
    }
?>