
<!-- Google Map
<div id="googleMap" class="w3-grayscale" style="width:100%;height:450px; background-color: #8c8c8c;"></div>
-->
<!-- Footer -->
<footer class="w3-center w3-black w3-padding-16">
	<p>photongreen.com.br<a href="https://www.w3schools.com/w3css/default.asp" title="W3.CSS" target="_blank" class="w3-hover-text-green"></a></p>
</footer>

<!-- Scripts adicionais -->

	<script type="text/javascript" src="./js/jquery.min.js"></script>
	<script type="text/javascript" src="./js/angular.min.js"></script>
	<script type="text/javascript" src="./js/bootstrap.js"></script>
	<script type="text/javascript" src="./js/calculo.js"></script>

<!-- Global site tag (gtag.js) - Google Analytics -->
<!-- <script async src="https://www.googletagmanager.com/gtag/js?id=UA-127321879-2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-127321879-2');
</script> -->
