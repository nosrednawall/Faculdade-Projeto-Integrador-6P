<?php
	$Servidor = "localhost";
	$DataBase = "aksvi562_photon_green";
	$Usuario = "aksvi562_photon";
	$Senha = "JZwZB{~{1NMf";
	
	$conexao = new PDO("mysql:host=$Servidor;dbname=$DataBase", $Usuario, $Senha);	
?>