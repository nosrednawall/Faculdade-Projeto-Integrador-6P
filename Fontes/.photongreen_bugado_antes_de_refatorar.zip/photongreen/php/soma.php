<?php 
    function sun(){
        echo "1+1";
    }
?>