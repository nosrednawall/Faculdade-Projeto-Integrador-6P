

	<nav class="navbar navbar-inverse" style="border-radius: 0; border: solid 0px black;">
	  <div class="container-fluid">
	    <div class="navbar-header">
	      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>                        
	      </button>
	      <a class="navbar-brand" href="#">PHOTONGREEN</a>
	    </div>
	    <div class="collapse navbar-collapse" id="myNavbar">
	      <ul class="nav navbar-nav">
	        <li class="active"><a href="/">Home </a></li>
	        <li><a href="#Empresa">Empresa</a></li>
	        <li><a href="#">Projetos</a></li>
	        <li><a href="/calcular.php">Calcular</a></li>
	        <li><a href="#">Produtos</a></li>
	        <li><a href="#Sobre">Sobre</a></li>
	        <li><a href="#Contato">Contato</a></li>
	      </ul>
	    </div>
	  </div>
	</nav>

